/* Elihav Sasson — editorial theme (ported from the approved demo, wired to Shopify) */
(function(){

/* ---------- scroll chrome + hero parallax ---------- */
window.addEventListener('scroll',function(){
  document.body.classList.toggle('scrolled',window.scrollY>30);
  var bg=document.getElementById('heroBg');
  if(bg&&window.scrollY<window.innerHeight){bg.style.transform='translateY('+(window.scrollY*0.18)+'px)';}
},{passive:true});

/* ---------- reveal on scroll ---------- */
var io=new IntersectionObserver(function(es){
  es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target);}});
},{threshold:.16});
document.querySelectorAll('.reveal').forEach(function(el){io.observe(el);});

/* ---------- money ---------- */
function formatMoney(cents){
  if(typeof cents==='string'){cents=cents.replace('.','');}
  var fmt=window.MONEY_FORMAT||'${{amount}}';
  var ph=/\{\{\s*(\w+)\s*\}\}/;
  function fwd(number,precision,thousands,decimal){
    precision=(precision==null)?2:precision;thousands=(thousands==null)?',':thousands;decimal=(decimal==null)?'.':decimal;
    if(isNaN(number)||number==null){return 0;}
    number=(number/100).toFixed(precision);
    var parts=number.split('.'),
      dollars=parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g,'$1'+thousands),
      c=parts[1]?decimal+parts[1]:'';
    return dollars+c;
  }
  var value='',m=fmt.match(ph);if(!m){return fmt;}
  switch(m[1]){
    case 'amount':value=fwd(cents,2);break;
    case 'amount_no_decimals':value=fwd(cents,0);break;
    case 'amount_with_comma_separator':value=fwd(cents,2,'.',',');break;
    case 'amount_no_decimals_with_comma_separator':value=fwd(cents,0,'.',',');break;
    case 'amount_with_space_separator':value=fwd(cents,2,' ','.');break;
    case 'amount_no_decimals_with_space_separator':value=fwd(cents,0,' ');break;
    default:value=fwd(cents,2);
  }
  return fmt.replace(ph,value);
}
window.esFormatMoney=formatMoney;

/* ---------- currency switcher (ILS / USD / EUR) — display, curated fixed rates ----------
   Auto-detects the visitor's region on first visit, remembers their choice,
   shows ONE clean price. Rates fixed + rounded so figures never flicker
   day-to-day. Update ES_FX if the shekel moves materially. */
var ES_FX={usd:0.27,eur:0.25};
function roundTo(n,s){return Math.round(n/s)*s;}
function detectCurrency(){try{var tz=(Intl.DateTimeFormat().resolvedOptions().timeZone)||'';if(tz==='Asia/Jerusalem'){return 'ILS';}if(tz.indexOf('Europe/')===0){return 'EUR';}if(tz.indexOf('America/')===0){return 'USD';}}catch(e){}return 'USD';}
var ES_CUR;try{ES_CUR=localStorage.getItem('es_cur')||detectCurrency();}catch(e){ES_CUR=detectCurrency();}
function formatPrice(cents){var ils=cents/100;if(ES_CUR==='USD'){return '$'+roundTo(ils*ES_FX.usd,100).toLocaleString('en-US');}if(ES_CUR==='EUR'){return '€'+roundTo(ils*ES_FX.eur,100).toLocaleString('en-US');}return '₪'+Math.round(ils).toLocaleString('en-US');}
function applyCurrency(){
  document.querySelectorAll('[data-ils-cents]').forEach(function(el){var c=parseInt(el.getAttribute('data-ils-cents'),10);if(c>0){el.textContent=formatPrice(c);}});
  document.querySelectorAll('#curSwitch button').forEach(function(b){b.classList.toggle('on',b.getAttribute('data-cur')===ES_CUR);});
  if(typeof GOWN!=='undefined'&&GOWN&&GOWN.price>0){var g=document.getElementById('gownPrice');if(g){g.textContent=formatPrice(GOWN.price);}}
}
function setCurrency(cur){ES_CUR=cur;try{localStorage.setItem('es_cur',cur);}catch(e){}applyCurrency();}
window.esFormatPrice=formatPrice;window.setCurrency=setCurrency;window.esApplyCurrency=applyCurrency;

/* ---------- Shopify cart ---------- */
function renderShopCart(c){
  var box=document.getElementById('cartItems');
  document.getElementById('cartCount').textContent=c.item_count;
  var sub=document.getElementById('cartSubtotal');if(sub){sub.innerHTML=formatMoney(c.items_subtotal_price);}
  if(!box){return;}
  if(!c.items.length){box.innerHTML='<p class="empty">Your cart is empty</p>';return;}
  box.innerHTML=c.items.map(function(it){
    var img=it.image||(it.featured_image&&it.featured_image.url)||'';
    return '<div class="ci"><img src="'+img+'" alt=""><div class="info">'
      +'<div class="n">'+it.product_title+'</div>'
      +'<div class="p">'+formatMoney(it.final_line_price)+(it.quantity>1?' &times; '+it.quantity:'')+'</div>'
      +'<button class="rm" data-key="'+it.key+'">Remove</button>'
      +'</div></div>';
  }).join('');
}
function fetchCart(cb){
  fetch('/cart.js',{headers:{'Accept':'application/json'}}).then(function(r){return r.json();}).then(function(c){renderShopCart(c);if(cb){cb(c);}}).catch(function(){});
}
function addItem(variantId,qty){
  if(!variantId){return;}
  fetch('/cart/add.js',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({id:variantId,quantity:qty||1})})
    .then(function(r){return r.json();}).then(function(){fetchCart(openCart);}).catch(function(){});
}
window.addEventListener('DOMContentLoaded',function(){
  var box=document.getElementById('cartItems');
  if(box){box.addEventListener('click',function(e){
    var b=e.target.closest('.rm');if(!b){return;}
    fetch('/cart/change.js',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({id:b.getAttribute('data-key'),quantity:0})})
      .then(function(r){return r.json();}).then(renderShopCart).catch(function(){});
  });}
  fetchCart();
  var cs=document.getElementById('curSwitch');
  if(cs){cs.addEventListener('click',function(e){var b=e.target.closest('button[data-cur]');if(b){setCurrency(b.getAttribute('data-cur'));}});}
  applyCurrency();
});
function checkout(){ if(document.querySelector('#cartItems .ci')){window.location.href='/checkout';} }
window.checkout=checkout;

/* ---------- drawers / menus ---------- */
function openCart(){document.getElementById('drawer').classList.add('open');document.getElementById('overlay').classList.add('open');}
function closeCart(){document.getElementById('drawer').classList.remove('open');document.getElementById('overlay').classList.remove('open');}
function openMenu(){document.getElementById('menuOverlay').classList.add('open');}
function closeMenu(){document.getElementById('menuOverlay').classList.remove('open');}
window.openCart=openCart;window.closeCart=closeCart;window.openMenu=openMenu;window.closeMenu=closeMenu;
window.esFetchCart=fetchCart;window.esAddItem=addItem;
function goSection(e,id){closeMenu();closeGallery();var el=document.getElementById(id);if(el){if(e&&e.preventDefault){e.preventDefault();}el.scrollIntoView({behavior:'smooth'});return false;}return true;}
window.goSection=goSection;

/* ---------- collections data ---------- */
var COLLECTIONS=window.COLLECTIONS||{};
function gEsc(s){return (s||'').replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function waLink(text){return 'https://wa.me/972515358153'+(text?'?text='+encodeURIComponent(text):'');}
var CUR_COLL=null;

function openCollection(key){
  var c=COLLECTIONS[key];if(!c){return;}
  CUR_COLL=key;closeMenu();
  document.getElementById('gEyebrow').textContent=c.eyebrow;
  document.getElementById('gTitle').textContent=c.title;
  var grid=document.getElementById('gGrid');
  grid.innerHTML=(c.items&&c.items.length)?c.items.map(function(it,idx){
    var hero=it.imgs[0]?it.imgs[0].src:'';
    var alt=it.imgs[1]?'<img class="alt" src="'+it.imgs[1].src+'" alt="" loading="lazy">':'';
    return '<div class="g-card" data-idx="'+idx+'"><div class="frame"><img src="'+hero+'" alt="'+gEsc(it.name)+'" loading="lazy">'+alt+'</div><div class="n">'+gEsc(it.name)+'</div><div class="enq">View &#8599;</div></div>';
  }).join(''):'<div class="g-empty">Collection coming soon</div>';
  document.getElementById('gCta').setAttribute('href',waLink('Hello Elihav Sasson, I’d like to book a private fitting for the '+c.title+' collection.'));
  var ov=document.getElementById('galleryOverlay');ov.scrollTop=0;ov.classList.add('open');ov.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';
}
function closeGallery(){
  document.getElementById('galleryOverlay').classList.remove('open');
  document.getElementById('galleryOverlay').setAttribute('aria-hidden','true');
  if(!document.getElementById('gownOverlay').classList.contains('open')){document.body.style.overflow='';}
}
window.openCollection=openCollection;window.closeGallery=closeGallery;
var gGrid=document.getElementById('gGrid');
if(gGrid){gGrid.addEventListener('click',function(e){var card=e.target.closest('.g-card');if(!card||!CUR_COLL){return;}openGown(CUR_COLL,parseInt(card.getAttribute('data-idx'),10));});}

/* ---------- gown detail carousel ---------- */
var GOWN=null,gIdx=0,gTimer=null;
function openGown(key,idx){
  var c=COLLECTIONS[key];if(!c||!c.items[idx]){return;}
  GOWN=c.items[idx];gIdx=0;
  document.getElementById('gownColl').textContent=c.title;
  document.getElementById('gownName').textContent=GOWN.name;
  document.getElementById('gownDesc').textContent=GOWN.desc||'';
  var _gp=document.getElementById('gownPrice');
  if(GOWN.price&&GOWN.price>0){_gp.textContent=formatPrice(GOWN.price);}else{_gp.textContent='Price on request';}
  var addBtn=document.getElementById('gownAdd');addBtn.textContent='Add to Cart';addBtn.removeAttribute('data-label');
  document.getElementById('gownFit').setAttribute('href',waLink('Hello Elihav Sasson, I’d love to book a private fitting for the '+GOWN.name+' gown from the '+c.title+' collection.'));
  var track=document.getElementById('gownTrack');
  track.innerHTML=GOWN.imgs.map(function(im,i){return '<img'+(i===0?' class="on"':'')+' src="'+im.src+'" alt="'+gEsc(GOWN.name)+'" '+(i>1?'loading="lazy"':'')+'>';}).join('');
  var dots=document.getElementById('gownDots');
  dots.innerHTML=GOWN.imgs.map(function(_,i){return '<span'+(i===0?' class="on"':'')+' data-i="'+i+'"></span>';}).join('');
  var multi=GOWN.imgs.length>1;
  document.getElementById('gPrev').style.display=multi?'flex':'none';
  document.getElementById('gNext').style.display=multi?'flex':'none';
  dots.style.display=multi?'flex':'none';
  gownShow(0);
  var ov=document.getElementById('gownOverlay');ov.classList.add('open');ov.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';
  if(multi){gTimer=setInterval(function(){gownStep(1);},4500);}
}
function gownShow(i){
  if(!GOWN){return;}
  var n=GOWN.imgs.length;gIdx=(i+n)%n;
  document.querySelectorAll('#gownTrack img').forEach(function(el,x){el.classList.toggle('on',x===gIdx);});
  document.querySelectorAll('#gownDots span').forEach(function(el,x){el.classList.toggle('on',x===gIdx);});
  var cap=GOWN.imgs[gIdx]&&GOWN.imgs[gIdx].cap?GOWN.imgs[gIdx].cap:'';
  document.getElementById('gownCap').textContent=cap;
}
function gownStep(d){gownShow(gIdx+d);resetGownTimer();}
function resetGownTimer(){if(gTimer){clearInterval(gTimer);if(GOWN&&GOWN.imgs.length>1){gTimer=setInterval(function(){gownShow(gIdx+1);},4500);}}}
function closeGown(){
  document.getElementById('gownOverlay').classList.remove('open');
  document.getElementById('gownOverlay').setAttribute('aria-hidden','true');
  if(gTimer){clearInterval(gTimer);gTimer=null;}GOWN=null;
  if(document.getElementById('galleryOverlay').classList.contains('open')){document.body.style.overflow='hidden';}else{document.body.style.overflow='';}
}
window.openGown=openGown;window.gownStep=gownStep;window.closeGown=closeGown;
var gownDots=document.getElementById('gownDots');
if(gownDots){gownDots.addEventListener('click',function(e){var s=e.target.closest('span');if(s){gownShow(parseInt(s.getAttribute('data-i'),10));resetGownTimer();}});}
(function(){var sx=null;var stage=document.querySelector('.gown-stage');
  if(stage){stage.addEventListener('touchstart',function(e){sx=e.touches[0].clientX;},{passive:true});
    stage.addEventListener('touchend',function(e){if(sx===null)return;var dx=e.changedTouches[0].clientX-sx;if(Math.abs(dx)>40){gownStep(dx<0?1:-1);}sx=null;},{passive:true});}
})();
document.addEventListener('keydown',function(e){
  if(e.key==='Escape'){if(document.getElementById('gownOverlay').classList.contains('open')){closeGown();}else{closeGallery();closeMenu();}}
  if(document.getElementById('gownOverlay').classList.contains('open')){if(e.key==='ArrowLeft')gownStep(-1);if(e.key==='ArrowRight')gownStep(1);}
});
function addGownToCart(){
  if(!GOWN){return;}
  if(GOWN.variantId){addItem(GOWN.variantId,1);var b=document.getElementById('gownAdd');if(b){var t=b.getAttribute('data-label')||b.textContent;b.setAttribute('data-label',t);b.textContent='Added ✓';setTimeout(function(){b.textContent=t;},1300);}}
  else{window.open(waLink('Hello Elihav Sasson, I’d like to enquire about the '+GOWN.name+' gown.'),'_blank');}
}
window.addGownToCart=addGownToCart;

/* ---------- whatsapp cart enquiry ---------- */
function waEnquire(){
  fetch('/cart.js',{headers:{'Accept':'application/json'}}).then(function(r){return r.json();}).then(function(c){
    if(!c.items.length){return;}
    var lines=c.items.map(function(i){return '• '+i.product_title+(i.quantity>1?' ×'+i.quantity:'');});
    var msg='Hello Elihav Sasson,\nI’m interested in these pieces:\n\n'+lines.join('\n')+'\n\nCould you assist me?';
    window.open(waLink(msg),'_blank');
  });
}
window.waEnquire=waEnquire;

/* ---------- misc ---------- */
setTimeout(function(){var w=document.querySelector('.wa-btn');if(!w){return;}w.classList.add('reveal');setTimeout(function(){w.classList.remove('reveal');},4200);},2800);
function submitCatalogue(e){e.preventDefault();document.getElementById('msg').textContent='Thank you — your lookbook is on its way.';e.target.reset();return false;}
window.submitCatalogue=submitCatalogue;
setTimeout(function(){var c=document.querySelector('.curtain');if(c){c.style.display='none';}},3200);
(function(){var v=document.querySelector('.hero video');if(v){var p=v.play();if(p&&p.catch){p.catch(function(){});}}})();

})();
